//
//  ContentView.swift
//  YelpDemo
//
//  Created by duongpham on 14/05/2023.
//

import SwiftUI

struct ContentView: View {
    
    @ObservedObject var networkManager = NetworkManager()
    @State private var keyword: String = ""
    var body: some View {
        let bindingKeyword = Binding<String>(get: {
            self.keyword
        }, set: {
            self.keyword = $0
            networkManager.fetchListData(with: $0)
        })
        
        VStack {
            TextField("Enter your keyword", text: bindingKeyword)
                .background(.red)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .cornerRadius(16)
    
            List(networkManager.businesses) { business in
                HStack {
                    AsyncImage(url: URL(string: business.imageUrl!)) { image in
                        image.image?.resizable()
                    }
                    .frame(width: 50, height: 50)
                    Text(business.name ?? "")
                }
                
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
